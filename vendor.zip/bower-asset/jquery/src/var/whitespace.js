define( function() {

"use strict";

// https://www.w3.org/TR/css3-selectors/#whitespace
return "[\\x20\\t\\r\\n\\f]";

} );
